# Handoff: TDTB morning planning, flavor 2a ("Merged")

## Overview
Three screens of the TDTB morning planning flow: **Set up day**, **Plan tasks**, and **Connections**. Flavor 2a was picked from a round of two flavors (1a Timeline-first, 1b List-first). It uses 1a as the base, keeps the full-size timeline on both Set up and Plan, takes the Assigned/Skip row control and the sources nav + detail pane from 1b, and shows row actions as expanded icon buttons.

## About the design files
`Planning 2a.dc.html` is a **design reference built in HTML**. It is a static mockup showing the intended look, not production code. Rebuild it in the TDTB codebase with its existing components and patterns. Open the file in a browser (keep `support.js` beside it) to view it.

## Fidelity
**High fidelity** for layout, hierarchy, copy and colors. All data is fixture data (Sat 18 Jul, sample tasks). The screens are not interactive. Behavior below describes intent.

## Shared changes (apply to every screen)
- Anchors are no longer a grid of icon buttons with separate eye/clock/details buttons.
- No mono "text → daily note" or "pool → Live block" labels on prompts.
- No per-prompt export checkboxes. **Every filled prompt goes to the Todoist Inbox at Commit.** A single line explains this: "Filled prompts are added to your Todoist Inbox when you commit. Intention stays in today's note."

## Frame (all screens)
Artboard 1500×1000 min, background `#fbfaf7`.
- **Header** 68px, padding 0 36px, bottom border `1px #e3e0d8`. Left: date "Sat 18 Jul" (17px/600) over "Workday · 7:30 AM–11 PM" (12px, `#6b6862`); stepper (13px): active step is a pill `#1d1c1a` bg / white text, padding 8×14, radius 999; done step `#1f8a5e` with ✓; future `#9a968e`; 24px `#cfccc4` connector lines. Right: "Sources healthy · 6 skipped" pill (12px, `#1f8a5e`, border `#bfe3d1`) and "Connections" pill button (13px, border `#d6d3cb`; filled `#1d1c1a` on the Connections page).
- **Footer** 96px, padding 0 36px, top border `#e3e0d8`. Left: save status + "Day budget: 4/4 calls left" chip (12px, bg `#efede8`, border `#dedbd3`, radius 999). Right: warning chip (bg `#fdf1d6`, border `#f0d28d`, radius 6), secondary button (border `#d6d3cb`, radius 8, padding 12×18), primary button (bg `#1f9d6b`, white, radius 8, padding 12×18, 14px).

## Screen 1: Set up day
Content padding 32px 36px, vertical stack with gap 24.
1. **"Your day" card** (bg #fff, border `#e3e0d8`, radius 12, padding 22×24).
   - Title row: "Your day" (17/600) + helper "Click an anchor to edit it. Drag to move it or pick Mint sessions." (13px muted). Right side: four inline fields, label 11px muted above value box (border `#dedbd3`, radius 6, padding 7×10, bg `#fbfaf7`): Preset "Automatic — config default", Start "7:30 AM", End "11:45 PM", Buffer "Standard (20%)".
   - Timeline grid: 90px label column + fluid track. The day frame runs 7:30a–11:45p, so x = (hour − 7.5) / 16.25. Hour ticks run 8a to 11p (12px muted).
     - Calendar lane 40px, bg `#f4f3ef`, radius 6. Event blocks: Standup bg `#fde2b0` / border `#f2b866`; PHEP sync bg `#cdebfa` / border `#8fd0f0`. The label sits **to the right of the block** (left = block end + 8px), not inside it.
     - Mint lane 32px. When off, show a hatched pattern (135°, `#f4f3ef`/`#ecebe6`, 6px stripes) with "Off today".
     - Anchors lane 96px with two sub-rows (top 6px / 52px), blocks 38px tall, bg `#dedcd6`, border `1px #b9b6af`, radius 6. Each block shows the name (12/500) and below it time + item count in mono 11px. Blocks shorter than 2h show the time only. Text ellipsizes. Row assignment: Morning Routine, Live and Night Routine on row 0; Foods Breakfast, Sudsing and Foods Dinner on row 1.
     - **Selected anchor**: bg `#ecebe6`, border `2px #1d1c1a`, with a popover anchored under it (300px wide, radius 10, shadow `0 10px 30px rgba(0,0,0,.14)`, padding 16). Popover contents: name + "N items"; Starts (mono time field) and Window ("Until 1:00 PM") side by side; "Count today" switch; footer links "Edit items" (green) · "Reset to default".
2. **Morning prompts**: header row "Morning prompts" (17/600) with "Edit prompts" link (`#1f8a5e`). Below it a 4-column grid of cards (bg #fff, radius 12, padding 16, gap 14):
   - Live micro-adventure: select "Watch sunset ▾" + "Shuffle" button; meta line "Nature · streak 3 · Use my own idea" (the link replaces the old Custom idea field).
   - Intention (placeholder "One thing to focus on today"), For Meegy, Stoic: textareas.
   - Below the grid: the export line (see Shared) and "+ Add prompt".
- Footer: "Not saved yet", "Undo", primary "Continue to tasks →".

## Screen 2: Plan tasks
Padding 32px 36px, vertical stack with gap 24.
1. Heading "Assigned this morning" (24/600) + "Edits here affect today only. Mark complete writes back to the source." (13px muted).
2. **Already placed card**: the same full timeline as Set up (Calendar / Mint / Anchors lanes) with no popover and no selected state. Header: "Already placed" (15/600), and on the right "Tasks are placed after you commit." Tasks and Capacities items never appear on this timeline.
3. Two-column grid (`1fr 380px`, gap 28):
   - **Left: task groups** in this order: **Critical → Fixed → When there's room**. Group header: 3px left rule in the group color (Critical `#e5484d`, Fixed `#3b9ede`, Room `#1f9d6b`), uppercase name (13/600, tracking .06em), description (13px muted).
   - **Task row** (bg #fff, border `#e3e0d8`, radius 10). Columns: status control | name + meta | duration | priority | actions.
     - Status: a toggle button reading "Assigned" (bg `#1f9d6b`, white) or "Unassigned" (white bg, border `#d6d3cb`). This is the default in this package. The alternatives are a segmented "Assigned | Skip" control and a switch (see Tweaks).
     - Name 15/500. Meta line 12px muted: an 8px source swatch (Todoist `#e5484d`, Capacities `#8b5cf6`), the source name, and the due date (warning color `#c27a00` for "due tomorrow").
     - Duration: label + small slider (track `#ebe9e3`, fill/knob `#3b7be8`).
     - Actions, expanded as 34px icon buttons with radius 7 and gap 6: **Complete** (filled `#1f9d6b` ✓), **Exclude today** (eye-off), **Exact duration** (clock), **Leave as-is** (undo arrow), **More** (⋯). Give each a tooltip/aria-label.
   - **Right: capacity card**: "6 blk left" (22/600), "of 31", a 10px stacked bar, and a legend with mono block counts (Calendar `#7cc8f0`, Work (Mint) `#f2a93b`, Anchors `#a9a6a0`, Habits `#f06fb4`, Tasks `#3b7be8`).
- Footer: "← Day setup", budget chip, warning, "Copy prompt", primary "Sequence & commit 13 blk".

## Screen 3: Connections (from 1b)
Two columns: 300px nav (right border `#e3e0d8`, padding 28×18) + detail pane (padding 28×36, max-width 880).
- **Nav**: "← Back to planning", then groups with uppercase 11px muted headers:
  - Sources: Todoist, Calendar, Capacities, each with a 7px health dot (green `#1f9d6b`, degraded `#e0a020`).
  - Capacities structures: custom-project (selected, bg `#efede8`, radius 7), Project 0d194525… (grey dot when off).
  - Rules: Exclude tags, Advanced.
- **Detail pane** for the selected structure:
  - Kicker "Capacities structure", title (24/600), helper "Items are admitted when any rule matches. Completed and dropped items are always left out.", and "Remove" on the right (muted).
  - Preview strip: "0 admitted today · 1 waiting on mapping · Note Processing".
  - "Admit when" list card with a switch on each row: Status is active / Due today or overdue / Deadline within 2 days. Then "Active means" with tag chips and "+ add".
  - Property mapping: input "Property id" + primary "Discover from Capacities".
- Footer: "No unsaved changes", Discard, Save.

## Interactions (intended)
- Set up: clicking an anchor block opens its popover; dragging moves it. Dragging on the Mint lane picks sessions. Escape or an outside click closes the popover.
- Plan: the status control flips Assigned/Unassigned for today only. The row icons map to the existing shortcuts C (complete), E (exclude), D (exact duration), plus Leave as-is and the More menu. Complete writes back to the source; the other actions apply to today only and can be undone.
- Connections: selecting a nav item swaps the detail pane. Save/Discard apply to all pending edits.
- Prompts: there is no export toggle. Every non-empty prompt except Intention is written to the Todoist Inbox at Commit.

## Tweaks explored (pick one when building)
- Status control: **Toggle button** (packaged default) / Segmented "Assigned | Skip" / Switch.
- Row actions: **Icons** (packaged default) / Labeled text buttons / ✓ + overflow menu.
- Density: **Compact** (packaged default: row padding 6×12, gap 4) / Comfortable (row padding 14×16, gap 10).

## Design tokens
- Ink `#1d1c1a`, body `#3d3b37`/`#4a4843`, muted `#6b6862`, faint `#9a968e`
- Surfaces: page `#fbfaf7`, card `#ffffff`, track `#f4f3ef`, chip `#efede8`
- Borders: `#e3e0d8` (cards), `#dedbd3` (inputs), `#d6d3cb` (buttons), `#eeece6`/`#f1efea` (dividers)
- Primary `#1f9d6b`; primary text `#1f8a5e`; warning bg `#fdf1d6`, border `#f0d28d`
- Radii: 5–7 (controls), 10 (rows, popover), 12 (cards), 999 (pills)
- Type: Helvetica Neue stack; mono `ui-monospace, Menlo` for times and block counts. Scale 11 / 12 / 13 / 14 / 15 / 17 / 22 / 24.

## Files
- `Planning 2a.dc.html`: the 2a mockup (Set up, Plan, Connections).
- `support.js`: runtime needed to open the mockup in a browser.
